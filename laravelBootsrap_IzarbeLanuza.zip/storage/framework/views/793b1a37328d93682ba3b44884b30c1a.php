<form action="<?php echo e($route); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <?php if(isset($update)): ?>
        <?php echo method_field("PUT"); ?>
    <?php endif; ?>

    <div class="mb-3">
        <label class="form-label">Nom ensenyament</label>

        <input type="text"
               name="nom"
               class="form-control"
               value="<?php echo e(old('nom', $ensenyament->nom ?? '')); ?>"
               required>
    </div>

    <button class="btn btn-primary">
        <?php echo e($textButton ?? "Guardar"); ?>

    </button>
</form>
<a href="<?php echo e(route('ensenyament.index')); ?>" class="btn btn-secondary">Volver</a><?php /**PATH C:\xampp\htdocs\ADBootStrap\crudlaravelbootstrap\resources\views/ensenyament/form.blade.php ENDPATH**/ ?>