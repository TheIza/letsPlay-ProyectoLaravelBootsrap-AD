<?php $__env->startSection('content'); ?>
<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom ">

        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <svg class="bi me-2" width="40" height="32">
                <use xlink:href="#bootstrap"></use>
            </svg>
            <span class="fs-4">
                - Crear un CRUD amb Laravel - <br>
                <strong>Izarbe Lanuza</strong>
            </span>
        </a>

        <ul class="nav nav-pills">



            
            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
            <li class="nav-item px-1">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-secondary">
                    Inicio
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="<?php echo e(url('alumne')); ?>" class="btn btn-outline-secondary">
                    Alumnes
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="<?php echo e(route('centre.index')); ?>" class="btn btn-outline-secondary">
                    Centres
                </a>
            </li>
             <li class="nav-item px-1">
                <a href="<?php echo e(route('ensenyament.index')); ?>" class="btn btn-outline-secondary">
                    Ensenyaments
                </a>
            </li>
            <li class="nav-item px-1">
                <a href="<?php echo e(url('/home')); ?>" class="btn btn-primary">
                    Dashboard
                </a>
            </li>

            <?php else: ?>
            <li class="nav-item px-1">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary">
                    Iniciar Sesión
                </a>
            </li>

            <?php if(Route::has('register')): ?>
            <li class="nav-item px-1">
                <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary">
                    Registrarse
                </a>
            </li>
            <?php endif; ?>
            <?php endif; ?>
            <?php endif; ?>

        </ul>
    </header>
</div>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
                <div class="card-header">
                    <?php echo e(__('Dashboard')); ?>

                </div>
   
                <div class="card-body">

                    <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <div class="container text-center mt-5">
                        <div class="row">

                            <div class="col">
                                <a href="<?php echo e(url('alumne')); ?>"
                                    class="btn btn-outline-primary btn-lg">
                                    👥 Llistat d'alumnes
                                </a>
                            </div>

                            <div class="col">
                                <a href="<?php echo e(url('centre')); ?>"
                                    class="btn btn-outline-primary btn-lg">
                                    🏛 Llistat de centres
                                </a>
                            </div>
                            <div class="col">
                                <a href="<?php echo e(url('ensenyament')); ?>"
                                    class="btn btn-outline-primary btn-lg">
                                    📚 Llistat d'ensenyaments
                                </a>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\izarb\Desktop\DAM\AD\ADBootStrap\crudlaravelbootstrap\resources\views/home.blade.php ENDPATH**/ ?>