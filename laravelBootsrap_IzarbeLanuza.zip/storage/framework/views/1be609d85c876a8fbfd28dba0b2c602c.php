

<?php $__env->startSection("content"); ?>

<div class="container mt-5">

    <div class="text-center mb-4">
        <h1><?php echo e(__("Fitxa de l'alumne")); ?></h1>
    </div>

    <div class="card">
        <div class="card-body">

            <div class="mb-3">
                <strong><?php echo e(__("Nom:")); ?></strong>
                <p><?php echo e($alumne->nom); ?></p>
            </div>

            <div class="mb-3">
                <strong><?php echo e(__("Cognoms:")); ?></strong>
                <p><?php echo e($alumne->cognoms); ?></p>
            </div>

            <div class="mb-3">
                <strong><?php echo e(__("Data de naixement:")); ?></strong>
                <p><?php echo e(date_format(new DateTime($alumne->data_naixement), "d/m/Y")); ?></p>
            </div>

            <div class="mb-3">
                <strong><?php echo e(__("Centre:")); ?></strong>
                <p><?php echo e($alumne->centre->nom ?? '—'); ?></p>
            </div>

            <div class="mb-3">
                <strong><?php echo e(__("Ensenyament:")); ?></strong>
                <p><?php echo e($alumne->ensenyament->nom ?? '—'); ?></p>
            </div>

            <a href="<?php echo e(route('alumne.index')); ?>" class="btn btn-secondary"> volver </a>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\izarb\Desktop\DAM\AD\ADBootStrap\crudlaravelbootstrap\resources\views/alumne/show.blade.php ENDPATH**/ ?>