

<?php $__env->startSection("content"); ?>

<div class="container">

    <h2><?php echo e($title); ?></h2>

    <?php echo $__env->make("ensenyament.form", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<a href="<?php echo e(route('ensenyament.index')); ?>" class="btn btn-secondary">Volver</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ADBootStrap\crudlaravelbootstrap\resources\views/ensenyament/edit.blade.php ENDPATH**/ ?>