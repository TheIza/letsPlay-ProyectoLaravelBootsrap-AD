
<?php $__env->startSection("content"); ?>
<div class="container mt-5">
    <?php echo $__env->make("alumne.form", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<a href="<?php echo e(route('alumne.index')); ?>" class="btn btn-secondary">Volver</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ADBootStrap\crudlaravelbootstrap\resources\views/alumne/edit.blade.php ENDPATH**/ ?>