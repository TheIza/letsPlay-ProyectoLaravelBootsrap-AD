

<?php $__env->startSection("content"); ?>

<div class="container">

    
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">

        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <span class="fs-4">
                - Crear un CRUD amb Laravel - <br>
                <strong>Izarbe Lanuza</strong>
            </span>
        </a>

        <ul class="nav nav-pills">

            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>

            <li class="nav-item px-1">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-secondary">
                    Inicio
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="<?php echo e(url('alumne')); ?>" class="btn btn-outline-secondary">
                    Alumnes
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="<?php echo e(route('centre.index')); ?>" class="btn btn-outline-secondary">
                    Centres
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="<?php echo e(route('ensenyament.index')); ?>" class="btn btn-primary">
                    Ensenyaments
                </a>
            </li>
            <li class="nav-item px-1">
                <a href="<?php echo e(url('/home')); ?>" class="btn btn-outline-secondary">
                    Dashboard
                </a>
            </li>

            <?php endif; ?>
            <?php endif; ?>

        </ul>
    </header>


    
    <div class="text-center mt-5">
        <h1><?php echo e(__("Llistat d'ensenyaments")); ?></h1>

        <a href="<?php echo e(route("ensenyament.create")); ?>" class="btn btn-primary">
            <?php echo e(__("Afegir ensenyament")); ?>

        </a>
    </div>


    
    <table class="table table-bordered mt-5 mb-5">

        <thead>
            <tr class="table-success">
                <th>Id</th>
                <th>Nom</th>
                <th>Accions</th>
            </tr>
        </thead>

        <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $ensenyaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ensenyament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>
                <td><?php echo e($ensenyament->id); ?></td>
                <td><?php echo e($ensenyament->nom); ?></td>

                <td>

                    <a href="<?php echo e(route('ensenyament.edit', $ensenyament)); ?>"
                       class="btn btn-warning">
                        Editar
                    </a>

                    <a href="#"
                       class="btn btn-danger"
                       onclick="event.preventDefault();
                       document.getElementById('delete-ensenyament-<?php echo e($ensenyament->id); ?>').submit();">
                        Eliminar
                    </a>

                    <form
                        id="delete-ensenyament-<?php echo e($ensenyament->id); ?>"
                        action="<?php echo e(route('ensenyament.destroy', $ensenyament)); ?>"
                        method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("DELETE"); ?>
                    </form>

                </td>
            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>
                <td colspan="3" class="text-center">
                    <strong><?php echo e(__("No hi ha ensenyaments")); ?></strong>
                    <br>
                    <?php echo e(__("No hi ha cap dada a mostrar")); ?>

                </td>
            </tr>

        <?php endif; ?>

        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        <?php echo $ensenyaments->links(); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ADBootStrap\crudlaravelbootstrap\resources\views/ensenyament.blade.php ENDPATH**/ ?>