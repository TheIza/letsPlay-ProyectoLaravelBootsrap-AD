

<?php $__env->startSection("content"); ?>

<div class="container">

    <h2><?php echo e($title); ?></h2>

    <?php echo $__env->make("ensenyament.form", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\izarb\Desktop\DAM\AD\ADBootStrap\crudlaravelbootstrap\resources\views/ensenyament/edit.blade.php ENDPATH**/ ?>