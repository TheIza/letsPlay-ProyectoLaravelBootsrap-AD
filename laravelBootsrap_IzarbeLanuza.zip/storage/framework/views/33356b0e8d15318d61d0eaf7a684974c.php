<div class="mb-3">
    <label class="form-label">Nom del centre</label>

    <input type="text"
           name="nom"
           class="form-control"
           value="<?php echo e(old('nom', $centre->nom ?? '')); ?>"
           required>
</div>

<button class="btn btn-primary">
    <?php echo e($textButton ?? 'Guardar'); ?>

</button><?php /**PATH C:\xampp\htdocs\ADBootStrap\crudlaravelbootstrap\resources\views/centre/form.blade.php ENDPATH**/ ?>