

<?php $__env->startSection("content"); ?>

<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom ">

        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <svg class="bi me-2" width="40" height="32">
                <use xlink:href="#bootstrap"></use>
            </svg>
            <span class="fs-4">
                - Crear un CRUD amb Laravel - <br>
                <strong>Izarbe Lanuza</strong>
            </span>
        </a>

        <ul class="nav nav-pills">

            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>

            <li class="nav-item px-1">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-secondary">
                    Inicio
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="<?php echo e(url('alumne')); ?>" class="btn btn-outline-secondary">
                    Alumnes
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="<?php echo e(route('centre.index')); ?>" class="btn btn-primary">
                    Centres
                </a>
            </li>
            <li class="nav-item px-1">
                <a href="<?php echo e(route('ensenyament.index')); ?>" class="btn btn-outline-secondary">
                    Ensenyaments
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="<?php echo e(url('/home')); ?>" class="btn btn-outline-secondary">
                    Dashboard
                </a>
            </li>

            <?php else: ?>

            <li class="nav-item px-1">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary">
                    Iniciar Sesión
                </a>
            </li>

            <?php if(Route::has('register')): ?>
            <li class="nav-item px-1">
                <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary">
                    Registrarse
                </a>
            </li>
            <?php endif; ?>

            <?php endif; ?>
            <?php endif; ?>

        </ul>
    </header>
</div>


<div class="container mt-5">

    <div class="text-center">
        <h1><?php echo e(__("Llistat de centres")); ?></h1>

        <a href="<?php echo e(route("centre.create")); ?>" class="btn btn-primary">
            <?php echo e(__("Afegir centre")); ?>

        </a>
    </div>

    <table class="table table-bordered mb-5 mt-5">
        <thead>
            <tr class="table-success">
                <th><?php echo e(__("Id")); ?></th>
                <th><?php echo e(__("Nom")); ?></th>
                <th><?php echo e(__("Accions")); ?></th>
            </tr>
        </thead>

        <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $centres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <th><?php echo e($centre->id); ?></th>
                <td><?php echo e($centre->nom); ?></td>

                <td>
                    <a href="<?php echo e(route("centre.edit", ["centre" => $centre])); ?>" class="btn btn-warning">
                        <?php echo e(__("Editar")); ?>

                    </a>

                    <a href="#" class="btn btn-danger"
                        onclick="event.preventDefault(); document.getElementById('delete-project-<?php echo e($centre->id); ?>-form').submit();">
                        <?php echo e(__("Eliminar")); ?>

                    </a>

                    <form id="delete-project-<?php echo e($centre->id); ?>-form"
                        action="<?php echo e(route("centre.destroy", ["centre" => $centre])); ?>"
                        method="POST" class="hidden">
                        <?php echo method_field("DELETE"); ?>
                        <?php echo csrf_field(); ?>
                    </form>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="text-center">
                    <strong><?php echo e(__("No hi ha centres")); ?></strong>
                    <br>
                    <?php echo e(__("No hi ha cap dada a mostrar")); ?>

                </td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        <?php echo $centres->links(); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ADBootStrap\crudlaravelbootstrap\resources\views/centre.blade.php ENDPATH**/ ?>