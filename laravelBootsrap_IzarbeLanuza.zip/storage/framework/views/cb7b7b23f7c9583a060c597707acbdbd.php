<div class="mb-3">
    <label class="form-label">Nom del centre</label>

    <input type="text"
           name="nom"
           class="form-control"
           value="<?php echo e(old('nom', $centre->nom ?? '')); ?>"
           required>
</div>

<button class="btn btn-primary">
    <?php echo e($textButton ?? 'Guardar'); ?>

</button>
<br><br>
<a href="<?php echo e(route('centre.index')); ?>" class="btn btn-secondary">Volver</a><?php /**PATH C:\Users\izarb\Desktop\DAM\AD\ADBootStrap\crudlaravelbootstrap\resources\views/centre/form.blade.php ENDPATH**/ ?>