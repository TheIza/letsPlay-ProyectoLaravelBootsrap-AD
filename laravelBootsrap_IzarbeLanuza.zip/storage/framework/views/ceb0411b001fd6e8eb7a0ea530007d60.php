
<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2><?php echo e($title); ?></h2>
    <form action="<?php echo e($route); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('centre.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\ADBootStrap\crudlaravelbootstrap\resources\views/centre/edit.blade.php ENDPATH**/ ?>