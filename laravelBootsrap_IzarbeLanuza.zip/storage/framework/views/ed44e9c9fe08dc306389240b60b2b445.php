

<?php $__env->startSection("content"); ?>

<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom ">

        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <svg class="bi me-2" width="40" height="32">
                <use xlink:href="#bootstrap"></use>
            </svg>
            <span class="fs-4">
                - Crear un CRUD amb Laravel - <br>
                <strong>Izarbe Lanuza</strong>
            </span>
        </a>

        <ul class="nav nav-pills">



            
            <?php if(Route::has('login')): ?>
            <?php if(auth()->guard()->check()): ?>
            
            <li class="nav-item px-1">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-secondary">
                    Inicio
                </a>
            </li>

            
            <li class="nav-item px-1">
                <a href="<?php echo e(url('alumne')); ?>" class="btn btn-primary">
                    Alumnes
                </a>
            </li>
            <li class="nav-item px-1">
                <a href="<?php echo e(route('centre.index')); ?>" class="btn btn-outline-secondary">
                    Centres
                </a>
            </li>
            <li class="nav-item px-1">
                <a href="<?php echo e(route('ensenyament.index')); ?>" class="btn btn-outline-secondary">
                    Ensenyaments
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="<?php echo e(url('/home')); ?>" class="btn btn-outline-secondary">
                    Dashboard
                </a>
            </li>

            <?php else: ?>

            <li class="nav-item px-1">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary">
                    Iniciar Sesión
                </a>
            </li>

            <?php if(Route::has('register')): ?>
            <li class="nav-item px-1">
                <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary">
                    Registrarse
                </a>
            </li>
            <?php endif; ?>

            <?php endif; ?>
            <?php endif; ?>

        </ul>
    </header>
</div>


<div class="container mt-5">
    <div class="text-center">
        <h1><?php echo e(__("Llistat d'alumnes")); ?></h1>
        <a href="<?php echo e(route("alumne.create")); ?>" class="btn btn-primary">
            <?php echo e(__("Afegir alumne")); ?>

        </a>
    </div>

    <table class="table table-bordered mb-5 mt-5">
        <thead>
            <tr class="table-success">
                <th><?php echo e(__("Id")); ?></th>
                <th><?php echo e(__("Nom")); ?></th>
                <th><?php echo e(__("Cognoms")); ?></th>
                <th><?php echo e(__("Data naixement")); ?></th>
                <th><?php echo e(__("Centre")); ?></th>
                <th><?php echo e(__("Ensenyament")); ?></th>
                <th><?php echo e(__("Accions")); ?></th>
            </tr>
        </thead>

        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $alumnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>
                <th><?php echo e($alumne->id); ?></th>
                <td><?php echo e($alumne->nom); ?></td>
                <td><?php echo e($alumne->cognoms); ?></td>
                <td><?php echo e(date_format(new DateTime($alumne->data_naixement), "d/m/Y")); ?></td>

                <td>
                    <?php echo e($alumne->centre->nom ?? '—'); ?>

                </td>

                <td>
                    <?php echo e($alumne->ensenyament->nom ?? '—'); ?>

                </td>

                <td>


                    <a href="<?php echo e(route("alumne.edit", $alumne)); ?>" class="btn btn-warning">
                        <?php echo e(__("Editar")); ?>

                    </a>

                    <a href="#" class="btn btn-danger"
                        onclick="event.preventDefault();
                        document.getElementById('delete-project-<?php echo e($alumne->id); ?>-form').submit();">
                        <?php echo e(__("Eliminar")); ?>

                    </a>
                    <a href="<?php echo e(route('alumne.show', $alumne)); ?>" class="btn btn-info">
                        <?php echo e(__("Veure")); ?>

                    </a>

                    <form id="delete-project-<?php echo e($alumne->id); ?>-form"
                        action="<?php echo e(route("alumne.destroy", $alumne)); ?>"
                        method="POST">
                        <?php echo method_field("DELETE"); ?>
                        <?php echo csrf_field(); ?>
                    </form>
                </td>
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="7" class="text-center">
                    <strong><?php echo e(__("No hi ha alumnes")); ?></strong>
                </td>
            </tr>

            <?php endif; ?>
        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        <?php echo $alumnes->links(); ?>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\izarb\Desktop\DAM\AD\ADBootStrap\crudlaravelbootstrap\resources\views/alumne.blade.php ENDPATH**/ ?>