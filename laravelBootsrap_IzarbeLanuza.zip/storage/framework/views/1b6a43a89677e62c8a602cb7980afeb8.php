<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss', 'resources/js/app.js']); ?>
</head>

<body class="bg-white">
    <div class="container">
        <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom ">
            <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
                <span class="fs-4">- Crear un CRUD amb Laravel - <br> <strong>Izarbe Lanuza</strong></span>
            </a>

            <ul class="nav nav-pills">



                
                <?php if(Route::has('login')): ?>
                <?php if(auth()->guard()->check()): ?>

                <li class="nav-item px-1">
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-primary">
                        Inicio
                    </a>
                </li>

                <li class="nav-item px-1">
                    <a href="<?php echo e(url('alumne')); ?>" class="btn btn-outline-secondary">
                        Alumnes
                    </a>
                </li>

                <li class="nav-item px-1">
                    <a href="<?php echo e(route('centre.index')); ?>" class="btn btn-outline-secondary">
                        Centres
                    </a>
                </li>
                <li class="nav-item px-1">
                <a href="<?php echo e(route('ensenyament.index')); ?>" class="btn btn-outline-secondary">
                    Ensenyaments
                </a>
            </li>
                <li class="nav-item px-1">
                    <a href="<?php echo e(url('/home')); ?>" class="btn btn-outline-secondary">
                        Dashboard
                    </a>
                </li>

                <?php else: ?>
                <li class="nav-item px-1">
                    <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-secondary">
                        Iniciar Sesión
                    </a>
                </li>

                <?php if(Route::has('register')): ?>
                <li class="nav-item px-1">
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-secondary">
                        Registrarse
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
                <?php endif; ?>

            </ul>
        </header>
    </div>
    <div class="container">
        <div class="p-5 text-center rounded-3">
            <img src="https://i.pinimg.com/736x/47/9b/59/479b59dca59037dc7c706000d4cddb7e.jpg" width="500">
        </div>
    </div>
    <footer class="bg-dark text-white text-center py-3 mt-5">
        ~ Creado por Izarbe Lanuza ~
    </footer>

</body>

</html><?php /**PATH C:\xampp\htdocs\ADBootStrap\crudlaravelbootstrap\resources\views/welcome.blade.php ENDPATH**/ ?>