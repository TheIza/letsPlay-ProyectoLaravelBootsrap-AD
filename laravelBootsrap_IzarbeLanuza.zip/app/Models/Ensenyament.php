<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Ensenyament extends Model
{
    protected $fillable = [
        'nom'
    ];
}