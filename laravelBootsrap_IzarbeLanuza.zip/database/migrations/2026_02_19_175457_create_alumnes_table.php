<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
{
    Schema::disableForeignKeyConstraints();

    Schema::create('alumnes', function (Blueprint $table) {
        $table->id();
        $table->string('nom');
        $table->string('cognoms');
        $table->date('data_naixement');
        $table->unsignedBigInteger('centre_id');
        $table->foreign('centre_id')->references('id')->on('centres');
        # Si volem que quan s'esborri un centre no es violi la integritat referencial podem fer això
        #$table->unsignedBigInteger('centre_id')->nullable();
        #$table->foreign('centre_id')->references('id')->on('centres')->nullOnDelete();
        $table->timestamps();
    });

    Schema::enableForeignKeyConstraints();
}

/**
 * Reverse the migrations.
 *
 * @return void
 */
public function down()
{
    Schema::disableForeignKeyConstraints();
    Schema::dropIfExists('alumnes');
    Schema::enableForeignKeyConstraints();
}
};
