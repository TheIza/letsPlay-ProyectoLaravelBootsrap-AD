@extends('layouts.app')
@section('content')
<div class="container mt-5">
    <h2>{{ $title }}</h2>
    <form action="{{ $route }}" method="POST">
        @csrf
        @include('centre.form')
    </form>
</div>

@endsection