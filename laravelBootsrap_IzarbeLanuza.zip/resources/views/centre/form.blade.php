<div class="mb-3">
    <label class="form-label">Nom del centre</label>

    <input type="text"
           name="nom"
           class="form-control"
           value="{{ old('nom', $centre->nom ?? '') }}"
           required>
</div>

<button class="btn btn-primary">
    {{ $textButton ?? 'Guardar' }}
</button>
<br><br>
<a href="{{ route('centre.index') }}" class="btn btn-secondary">Volver</a>