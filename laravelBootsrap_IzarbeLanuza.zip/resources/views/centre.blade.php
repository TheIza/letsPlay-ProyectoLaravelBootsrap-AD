@extends('layouts.app')

@section("content")

<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom ">

        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <svg class="bi me-2" width="40" height="32">
                <use xlink:href="#bootstrap"></use>
            </svg>
            <span class="fs-4">
                - Crear un CRUD amb Laravel - <br>
                <strong>Izarbe Lanuza</strong>
            </span>
        </a>

        <ul class="nav nav-pills">

            @if (Route::has('login'))
            @auth

            <li class="nav-item px-1">
                <a href="{{ url('/') }}" class="btn btn-outline-secondary">
                    Inicio
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="{{ url('alumne') }}" class="btn btn-outline-secondary">
                    Alumnes
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="{{ route('centre.index') }}" class="btn btn-primary">
                    Centres
                </a>
            </li>
            <li class="nav-item px-1">
                <a href="{{ route('ensenyament.index') }}" class="btn btn-outline-secondary">
                    Ensenyaments
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="{{ url('/home') }}" class="btn btn-outline-secondary">
                    Dashboard
                </a>
            </li>

            @else

            <li class="nav-item px-1">
                <a href="{{ route('login') }}" class="btn btn-outline-primary">
                    Iniciar Sesión
                </a>
            </li>

            @if (Route::has('register'))
            <li class="nav-item px-1">
                <a href="{{ route('register') }}" class="btn btn-outline-primary">
                    Registrarse
                </a>
            </li>
            @endif

            @endauth
            @endif

        </ul>
    </header>
</div>


<div class="container mt-5">

    <div class="text-center">
        <h1>{{ __("Llistat de centres") }}</h1>

        <a href="{{ route("centre.create") }}" class="btn btn-primary">
            {{ __("Afegir centre") }}
        </a>
    </div>

    <table class="table table-bordered mb-5 mt-5">
        <thead>
            <tr class="table-success">
                <th>{{ __("Id") }}</th>
                <th>{{ __("Nom") }}</th>
                <th>{{ __("Accions") }}</th>
            </tr>
        </thead>

        <tbody>

            @forelse($centres as $centre)
            <tr>
                <th>{{ $centre->id }}</th>
                <td>{{ $centre->nom }}</td>

                <td>
                    <a href="{{ route("centre.edit", ["centre" => $centre]) }}" class="btn btn-warning">
                        {{ __("Editar") }}
                    </a>

                    <a href="#" class="btn btn-danger"
                        onclick="event.preventDefault(); document.getElementById('delete-project-{{ $centre->id }}-form').submit();">
                        {{ __("Eliminar") }}
                    </a>

                    <form id="delete-project-{{ $centre->id }}-form"
                        action="{{ route("centre.destroy", ["centre" => $centre]) }}"
                        method="POST" class="hidden">
                        @method("DELETE")
                        @csrf
                    </form>
                </td>
            </tr>

            @empty
            <tr>
                <td colspan="4" class="text-center">
                    <strong>{{ __("No hi ha centres") }}</strong>
                    <br>
                    {{ __("No hi ha cap dada a mostrar") }}
                </td>
            </tr>
            @endforelse

        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        {!! $centres->links() !!}
    </div>

</div>

@endsection