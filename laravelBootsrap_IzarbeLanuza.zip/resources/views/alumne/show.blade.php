@extends('layouts.app')

@section("content")

<div class="container mt-5">

    <div class="text-center mb-4">
        <h1>{{ __("Fitxa de l'alumne") }}</h1>
    </div>

    <div class="card">
        <div class="card-body">

            <div class="mb-3">
                <strong>{{ __("Nom:") }}</strong>
                <p>{{ $alumne->nom }}</p>
            </div>

            <div class="mb-3">
                <strong>{{ __("Cognoms:") }}</strong>
                <p>{{ $alumne->cognoms }}</p>
            </div>

            <div class="mb-3">
                <strong>{{ __("Data de naixement:") }}</strong>
                <p>{{ date_format(new DateTime($alumne->data_naixement), "d/m/Y") }}</p>
            </div>

            <div class="mb-3">
                <strong>{{ __("Centre:") }}</strong>
                <p>{{ $alumne->centre->nom ?? '—' }}</p>
            </div>

            <div class="mb-3">
                <strong>{{ __("Ensenyament:") }}</strong>
                <p>{{ $alumne->ensenyament->nom ?? '—' }}</p>
            </div>

            <a href="{{ route('alumne.index') }}" class="btn btn-secondary"> volver </a>

        </div>
    </div>

</div>

@endsection