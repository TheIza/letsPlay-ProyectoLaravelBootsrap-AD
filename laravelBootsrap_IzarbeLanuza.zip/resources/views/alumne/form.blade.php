<div class="w-full">
    <div class="flex flex-wrap">
        <h1 class="mb-5">{{ $title }}</h1>
    </div>
</div>

<form method="POST" action="{{ $route }}" class="needs-validation">
    @csrf
    @isset($update)
        @method("PUT")
    @endisset

    {{-- NOM --}}
    <div class="mb-3">
        <label for="nom" class="form-label">{{ __("Nom") }}</label>
        <input name="nom" type="text" class="form-control"
               value="{{ old("nom") ?? $alumne->nom }}">

        @error("nom")
        <div class="fs-6 text-danger">{{ $message }}</div>
        @enderror
    </div>

    {{-- COGNOMS --}}
    <div class="mb-3">
        <label for="cognoms" class="form-label">{{ __("Cognoms") }}</label>
        <input name="cognoms" type="text" class="form-control"
               value="{{ old("cognoms") ?? $alumne->cognoms }}">

        @error("cognoms")
        <div class="fs-6 text-danger">{{ $message }}</div>
        @enderror
    </div>

    {{-- DATA NAIXEMENT --}}
    <div class="mb-3">
        <label class="form-label">{{ __("Data de naixement") }}</label>
        <input name="data_naixement" type="date" class="form-control"
               value="{{ old("data_naixement") ?? $alumne->data_naixement }}">

        @error("data_naixement")
        <div class="fs-6 text-danger">{{ $message }}</div>
        @enderror
    </div>

    {{-- CENTRE --}}
    <div class="mb-3">
        <label class="form-label">{{ __("Centre") }}</label>

        <select class="form-select" name="centre_id">
            @foreach ($centres as $centre)
                <option value="{{ $centre->id }}"
                    {{ $centre->id == ($alumne->centre_id ?? old('centre_id')) ? 'selected' : '' }}>
                    {{ $centre->nom }}
                </option>
            @endforeach
        </select>

        @error("centre_id")
        <div class="fs-6 text-danger">{{ $message }}</div>
        @enderror
    </div>

    {{-- ENSENYAMENT --}}
    <div class="mb-3">
        <label class="form-label">{{ __("Ensenyament") }}</label>

        <select class="form-select" name="ensenyament_id">

            <option value="">{{ __("Selecciona ensenyament") }}</option>

            @foreach ($ensenyaments as $ensenyament)

                <option value="{{ $ensenyament->id }}"
                    {{ $ensenyament->id == ($alumne->ensenyament_id ?? old('ensenyament_id')) ? 'selected' : '' }}>
                    {{ $ensenyament->nom }}
                </option>

            @endforeach

        </select>

        @error("ensenyament_id")
        <div class="fs-6 text-danger">{{ $message }}</div>
        @enderror
    </div>

    {{-- BOTON --}}
    <div class="mb-3">
        <button class="btn btn-primary" type="submit">
            {{ $textButton }}
        </button>
    </div>
</form>
<br>
<a href="{{ route('alumne.index') }}" class="btn btn-secondary">Volver</a>