@extends("layouts.app")

@section("content")

<div class="container">

    <h2>{{ $title }}</h2>

    @include("ensenyament.form")

</div>

@endsection