<form action="{{ $route }}" method="POST">
    @csrf

    @if(isset($update))
        @method("PUT")
    @endif

    <div class="mb-3">
        <label class="form-label">Nom ensenyament</label>

        <input type="text"
               name="nom"
               class="form-control"
               value="{{ old('nom', $ensenyament->nom ?? '') }}"
               required>
    </div>

    <button class="btn btn-primary">
        {{ $textButton ?? "Guardar" }}
    </button>
    
</form>
<br>
<a href="{{ route('ensenyament.index') }}" class="btn btn-secondary">Volver</a>