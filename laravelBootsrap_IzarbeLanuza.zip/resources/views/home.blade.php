@extends('layouts.app')

@section('content')
<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom ">

        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <svg class="bi me-2" width="40" height="32">
                <use xlink:href="#bootstrap"></use>
            </svg>
            <span class="fs-4">
                - Crear un CRUD amb Laravel - <br>
                <strong>Izarbe Lanuza</strong>
            </span>
        </a>

        <ul class="nav nav-pills">



            {{-- AUTH --}}
            @if (Route::has('login'))
            @auth
            <li class="nav-item px-1">
                <a href="{{ url('/') }}" class="btn btn-outline-secondary">
                    Inicio
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="{{ url('alumne') }}" class="btn btn-outline-secondary">
                    Alumnes
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="{{ route('centre.index') }}" class="btn btn-outline-secondary">
                    Centres
                </a>
            </li>
             <li class="nav-item px-1">
                <a href="{{ route('ensenyament.index') }}" class="btn btn-outline-secondary">
                    Ensenyaments
                </a>
            </li>
            <li class="nav-item px-1">
                <a href="{{ url('/home') }}" class="btn btn-primary">
                    Dashboard
                </a>
            </li>

            @else
            <li class="nav-item px-1">
                <a href="{{ route('login') }}" class="btn btn-outline-primary">
                    Iniciar Sesión
                </a>
            </li>

            @if (Route::has('register'))
            <li class="nav-item px-1">
                <a href="{{ route('register') }}" class="btn btn-outline-primary">
                    Registrarse
                </a>
            </li>
            @endif
            @endauth
            @endif

        </ul>
    </header>
</div>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="card">
                <div class="card-header">
                    {{ __('Dashboard') }}
                </div>
   
                <div class="card-body">

                    @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                    @endif

                    <div class="container text-center mt-5">
                        <div class="row">

                            <div class="col">
                                <a href="{{ url('alumne') }}"
                                    class="btn btn-outline-primary btn-lg">
                                    👥 Llistat d'alumnes
                                </a>
                            </div>

                            <div class="col">
                                <a href="{{ url('centre') }}"
                                    class="btn btn-outline-primary btn-lg">
                                    🏛 Llistat de centres
                                </a>
                            </div>
                            <div class="col">
                                <a href="{{ url('ensenyament') }}"
                                    class="btn btn-outline-primary btn-lg">
                                    📚 Llistat d'ensenyaments
                                </a>
                            </div>

                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

@endsection