@extends('layouts.app')

@section("content")

<div class="container">

    {{-- HEADER --}}
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom">

        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <span class="fs-4">
                - Crear un CRUD amb Laravel - <br>
                <strong>Izarbe Lanuza</strong>
            </span>
        </a>

        <ul class="nav nav-pills">

            @if (Route::has('login'))
            @auth

            <li class="nav-item px-1">
                <a href="{{ url('/') }}" class="btn btn-outline-secondary">
                    Inicio
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="{{ url('alumne') }}" class="btn btn-outline-secondary">
                    Alumnes
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="{{ route('centre.index') }}" class="btn btn-outline-secondary">
                    Centres
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="{{ route('ensenyament.index') }}" class="btn btn-primary">
                    Ensenyaments
                </a>
            </li>
            <li class="nav-item px-1">
                <a href="{{ url('/home') }}" class="btn btn-outline-secondary">
                    Dashboard
                </a>
            </li>

            @endauth
            @endif

        </ul>
    </header>


    {{-- TITULO + BOTON CREAR --}}
    <div class="text-center mt-5">
        <h1>{{ __("Llistat d'ensenyaments") }}</h1>

        <a href="{{ route("ensenyament.create") }}" class="btn btn-primary">
            {{ __("Afegir ensenyament") }}
        </a>
    </div>


    {{-- TABLA --}}
    <table class="table table-bordered mt-5 mb-5">

        <thead>
            <tr class="table-success">
                <th>Id</th>
                <th>Nom</th>
                <th>Accions</th>
            </tr>
        </thead>

        <tbody>

        @forelse($ensenyaments as $ensenyament)

            <tr>
                <td>{{ $ensenyament->id }}</td>
                <td>{{ $ensenyament->nom }}</td>

                <td>

                    <a href="{{ route('ensenyament.edit', $ensenyament) }}"
                       class="btn btn-warning">
                        Editar
                    </a>

                    <a href="#"
                       class="btn btn-danger"
                       onclick="event.preventDefault();
                       document.getElementById('delete-ensenyament-{{ $ensenyament->id }}').submit();">
                        Eliminar
                    </a>

                    <form
                        id="delete-ensenyament-{{ $ensenyament->id }}"
                        action="{{ route('ensenyament.destroy', $ensenyament) }}"
                        method="POST">
                        @csrf
                        @method("DELETE")
                    </form>

                </td>
            </tr>

        @empty

            <tr>
                <td colspan="3" class="text-center">
                    <strong>{{ __("No hi ha ensenyaments") }}</strong>
                    <br>
                    {{ __("No hi ha cap dada a mostrar") }}
                </td>
            </tr>

        @endforelse

        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        {!! $ensenyaments->links() !!}
    </div>

</div>

@endsection