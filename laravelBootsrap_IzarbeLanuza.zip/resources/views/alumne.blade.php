@extends('layouts.app')

@section("content")

<div class="container">
    <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom ">

        <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <svg class="bi me-2" width="40" height="32">
                <use xlink:href="#bootstrap"></use>
            </svg>
            <span class="fs-4">
                - Crear un CRUD amb Laravel - <br>
                <strong>Izarbe Lanuza</strong>
            </span>
        </a>

        <ul class="nav nav-pills">



            {{-- Auth --}}
            @if (Route::has('login'))
            @auth
            {{-- Inicio --}}
            <li class="nav-item px-1">
                <a href="{{ url('/') }}" class="btn btn-outline-secondary">
                    Inicio
                </a>
            </li>

            {{-- CRUD navegación --}}
            <li class="nav-item px-1">
                <a href="{{ url('alumne') }}" class="btn btn-primary">
                    Alumnes
                </a>
            </li>
            <li class="nav-item px-1">
                <a href="{{ route('centre.index') }}" class="btn btn-outline-secondary">
                    Centres
                </a>
            </li>
            <li class="nav-item px-1">
                <a href="{{ route('ensenyament.index') }}" class="btn btn-outline-secondary">
                    Ensenyaments
                </a>
            </li>

            <li class="nav-item px-1">
                <a href="{{ url('/home') }}" class="btn btn-outline-secondary">
                    Dashboard
                </a>
            </li>

            @else

            <li class="nav-item px-1">
                <a href="{{ route('login') }}" class="btn btn-outline-primary">
                    Iniciar Sesión
                </a>
            </li>

            @if (Route::has('register'))
            <li class="nav-item px-1">
                <a href="{{ route('register') }}" class="btn btn-outline-primary">
                    Registrarse
                </a>
            </li>
            @endif

            @endauth
            @endif

        </ul>
    </header>
</div>


<div class="container mt-5">
    <div class="text-center">
        <h1>{{ __("Llistat d'alumnes") }}</h1>
        <a href="{{ route("alumne.create") }}" class="btn btn-primary">
            {{ __("Afegir alumne") }}
        </a>
    </div>

    <table class="table table-bordered mb-5 mt-5">
        <thead>
            <tr class="table-success">
                <th>{{ __("Id") }}</th>
                <th>{{ __("Nom") }}</th>
                <th>{{ __("Cognoms") }}</th>
                <th>{{ __("Data naixement") }}</th>
                <th>{{ __("Centre") }}</th>
                <th>{{ __("Ensenyament") }}</th>
                <th>{{ __("Accions") }}</th>
            </tr>
        </thead>

        <tbody>
            @forelse($alumnes as $alumne)

            <tr>
                <th>{{ $alumne->id }}</th>
                <td>{{ $alumne->nom }}</td>
                <td>{{ $alumne->cognoms }}</td>
                <td>{{ date_format(new DateTime($alumne->data_naixement), "d/m/Y") }}</td>

                <td>
                    {{ $alumne->centre->nom ?? '—' }}
                </td>

                <td>
                    {{ $alumne->ensenyament->nom ?? '—' }}
                </td>

                <td>


                    <a href="{{ route("alumne.edit", $alumne) }}" class="btn btn-warning">
                        {{ __("Editar") }}
                    </a>

                    <a href="#" class="btn btn-danger"
                        onclick="event.preventDefault();
                        document.getElementById('delete-project-{{ $alumne->id }}-form').submit();">
                        {{ __("Eliminar") }}
                    </a>
                    <a href="{{ route('alumne.show', $alumne) }}" class="btn btn-info">
                        {{ __("Veure") }}
                    </a>

                    <form id="delete-project-{{ $alumne->id }}-form"
                        action="{{ route("alumne.destroy", $alumne) }}"
                        method="POST">
                        @method("DELETE")
                        @csrf
                    </form>
                </td>
            </tr>

            @empty
            <tr>
                <td colspan="7" class="text-center">
                    <strong>{{ __("No hi ha alumnes") }}</strong>
                </td>
            </tr>

            @endforelse
        </tbody>
    </table>

    <div class="d-flex justify-content-center">
        {!! $alumnes->links() !!}
    </div>

</div>

@endsection