<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    @vite(['resources/sass/app.scss', 'resources/js/app.js'])
</head>

<body class="bg-white">
    <div class="container">
        <header class="d-flex flex-wrap justify-content-center py-3 mb-4 border-bottom ">
            <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
                <span class="fs-4">- Crear un CRUD amb Laravel - <br> <strong>Izarbe Lanuza</strong></span>
            </a>

            <ul class="nav nav-pills">



                {{-- AUTH --}}
                @if (Route::has('login'))
                @auth

                <li class="nav-item px-1">
                    <a href="{{ url('/') }}" class="btn btn-primary">
                        Inicio
                    </a>
                </li>

                <li class="nav-item px-1">
                    <a href="{{ url('alumne') }}" class="btn btn-outline-secondary">
                        Alumnes
                    </a>
                </li>

                <li class="nav-item px-1">
                    <a href="{{ route('centre.index') }}" class="btn btn-outline-secondary">
                        Centres
                    </a>
                </li>
                <li class="nav-item px-1">
                <a href="{{ route('ensenyament.index') }}" class="btn btn-outline-secondary">
                    Ensenyaments
                </a>
            </li>
                <li class="nav-item px-1">
                    <a href="{{ url('/home') }}" class="btn btn-outline-secondary">
                        Dashboard
                    </a>
                </li>

                @else
                <li class="nav-item px-1">
                    <a href="{{ route('login') }}" class="btn btn-outline-secondary">
                        Iniciar Sesión
                    </a>
                </li>

                @if (Route::has('register'))
                <li class="nav-item px-1">
                    <a href="{{ route('register') }}" class="btn btn-outline-secondary">
                        Registrarse
                    </a>
                </li>
                @endif
                @endauth
                @endif

            </ul>
        </header>
    </div>
    <div class="container">
        <div class="p-5 text-center rounded-3">
            <img src="https://i.pinimg.com/736x/47/9b/59/479b59dca59037dc7c706000d4cddb7e.jpg" width="500">
        </div>
    </div>
    <footer class="bg-dark text-white text-center py-3 mt-5 ">
        ~ Creado por Izarbe Lanuza ~
    </footer>

</body>

</html>